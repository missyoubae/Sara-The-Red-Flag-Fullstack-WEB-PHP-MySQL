<?php
require_once 'config.php';

$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch($action) {

    // ===== GET ALL APPS =====
    case 'get_all':
        $db = getDB();
        $category = $_GET['category'] ?? 'all';

        if($category === 'all') {
            $result = $db->query("SELECT * FROM apps WHERE status = 'active' ORDER BY created_at DESC");
        } else {
            $stmt = $db->prepare("SELECT * FROM apps WHERE status = 'active' AND category = ? ORDER BY created_at DESC");
            $stmt->bind_param("s", $category);
            $stmt->execute();
            $result = $stmt->get_result();
        }

        $apps = [];
        while($row = $result->fetch_assoc()) {
            $apps[] = $row;
        }
        sendResponse(true, 'Apps loaded', $apps);
        break;

    // ===== ADD APP =====
    case 'add':
        if(!isset($_SESSION['staff'])) {
            sendResponse(false, 'Not authorized!');
        }

        $name = trim($_POST['name'] ?? '');
        $category = $_POST['category'] ?? '';
        $desc = trim($_POST['description'] ?? '');
        $size = trim($_POST['size'] ?? '');
        $rating = floatval($_POST['rating'] ?? 0);
        $link = trim($_POST['mega_link'] ?? '');
        $photo = trim($_POST['photo'] ?? '');
        $addedBy = $_SESSION['staff']['name'];

        if(empty($name) || empty($category) || empty($desc) || empty($link)) {
            sendResponse(false, 'Required fields missing!');
        }

        $db = getDB();
        $stmt = $db->prepare("INSERT INTO apps (name, category, description, file_size, rating, mega_link, photo, added_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssdsss", $name, $category, $desc, $size, $rating, $link, $photo, $addedBy);

        if($stmt->execute()) {
            sendResponse(true, 'App added!', ['id' => $db->insert_id]);
        } else {
            sendResponse(false, 'Failed to add app!');
        }
        break;

    // ===== DELETE APP =====
    case 'delete':
        if(!isset($_SESSION['staff'])) {
            sendResponse(false, 'Not authorized!');
        }

        $id = intval($_POST['id'] ?? 0);
        $db = getDB();
        $stmt = $db->prepare("DELETE FROM apps WHERE id = ?");
        $stmt->bind_param("i", $id);

        if($stmt->execute()) {
            sendResponse(true, 'App deleted!');
        } else {
            sendResponse(false, 'Failed!');
        }
        break;

    // ===== UPDATE APP =====
    case 'update':
        if(!isset($_SESSION['staff'])) {
            sendResponse(false, 'Not authorized!');
        }

        $id = intval($_POST['id'] ?? 0);
        $name = trim($_POST['name'] ?? '');
        $category = $_POST['category'] ?? '';
        $desc = trim($_POST['description'] ?? '');
        $size = trim($_POST['size'] ?? '');
        $rating = floatval($_POST['rating'] ?? 0);
        $link = trim($_POST['mega_link'] ?? '');
        $photo = trim($_POST['photo'] ?? '');

        $db = getDB();
        $stmt = $db->prepare("UPDATE apps SET name=?, category=?, description=?, file_size=?, rating=?, mega_link=?, photo=? WHERE id=?");
        $stmt->bind_param("ssssdssi", $name, $category, $desc, $size, $rating, $link, $photo, $id);

        if($stmt->execute()) {
            sendResponse(true, 'App updated!');
        } else {
            sendResponse(false, 'Failed!');
        }
        break;

    // ===== COUNT DOWNLOAD =====
    case 'download':
        $appId = intval($_POST['app_id'] ?? 0);
        $db = getDB();
        $db->query("UPDATE apps SET downloads = downloads + 1 WHERE id = $appId");

        if(isset($_SESSION['user'])) {
            $userId = $_SESSION['user']['id'];
            $appResult = $db->query("SELECT name FROM apps WHERE id = $appId");
            $app = $appResult->fetch_assoc();

            $stmt = $db->prepare("INSERT INTO downloads (user_id, app_id, app_name) VALUES (?, ?, ?)");
            $stmt->bind_param("iis", $userId, $appId, $app['name']);
            $stmt->execute();
        }

        sendResponse(true, 'Download counted!');
        break;

    // ===== GET COMMENTS =====
    case 'get_comments':
        $appId = intval($_GET['app_id'] ?? 0);
        $db = getDB();
        $result = $db->query("SELECT * FROM comments WHERE app_id = $appId AND status = 'active' ORDER BY created_at DESC");

        $comments = [];
        while($row = $result->fetch_assoc()) {
            $comments[] = $row;
        }
        sendResponse(true, 'Comments loaded', $comments);
        break;

    // ===== ADD COMMENT =====
    case 'add_comment':
        if(!isset($_SESSION['user'])) {
            sendResponse(false, 'Login to comment!');
        }

        $appId = intval($_POST['app_id'] ?? 0);
        $comment = trim($_POST['comment'] ?? '');
        $userId = $_SESSION['user']['id'];
        $username = $_SESSION['user']['username'];
        $photo = $_SESSION['user']['photo'] ?? '';

        if(empty($comment)) {
            sendResponse(false, 'Comment cannot be empty!');
        }

        $db = getDB();
        $stmt = $db->prepare("INSERT INTO comments (app_id, user_id, username, user_photo, comment) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("iisss", $appId, $userId, $username, $photo, $comment);

        if($stmt->execute()) {
            sendResponse(true, 'Comment added!', [
                'id' => $db->insert_id,
                'username' => $username,
                'user_photo' => $photo,
                'comment' => $comment,
                'created_at' => date('Y-m-d H:i:s')
            ]);
        } else {
            sendResponse(false, 'Failed!');
        }
        break;

    // ===== TOGGLE FAVORITE =====
    case 'toggle_favorite':
        if(!isset($_SESSION['user'])) {
            sendResponse(false, 'Login required!');
        }

        $appId = intval($_POST['app_id'] ?? 0);
        $userId = $_SESSION['user']['id'];
        $db = getDB();

        $check = $db->query("SELECT id FROM favorites WHERE user_id = $userId AND app_id = $appId");

        if($check->num_rows > 0) {
            $db->query("DELETE FROM favorites WHERE user_id = $userId AND app_id = $appId");
            sendResponse(true, 'Removed from favorites', ['action' => 'removed']);
        } else {
            $stmt = $db->prepare("INSERT INTO favorites (user_id, app_id) VALUES (?, ?)");
            $stmt->bind_param("ii", $userId, $appId);
            $stmt->execute();
            sendResponse(true, 'Added to favorites!', ['action' => 'added']);
        }
        break;

    default:
        sendResponse(false, 'Invalid action!');
        break;
}
?>