<?php
require_once 'config.php';

$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch($action) {

    // ===== SEND REQUEST =====
    case 'send':
        if(!isset($_SESSION['user'])) {
            sendResponse(false, 'Login required!');
        }

        $userId = $_SESSION['user']['id'];
        $username = $_SESSION['user']['username'];
        $email = $_SESSION['user']['email'];
        $appName = trim($_POST['app_name'] ?? '');
        $category = $_POST['category'] ?? 'gaming';
        $desc = trim($_POST['description'] ?? '');

        if(empty($appName)) {
            sendResponse(false, 'App name required!');
        }

        $db = getDB();
        $stmt = $db->prepare("INSERT INTO requests (user_id, username, email, app_name, category, description) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("isssss", $userId, $username, $email, $appName, $category, $desc);

        if($stmt->execute()) {
            sendResponse(true, 'Request sent to Sara!');
        } else {
            sendResponse(false, 'Failed!');
        }
        break;

    // ===== GET ALL REQUESTS STAFF =====
    case 'get_all':
        if(!isset($_SESSION['staff'])) {
            sendResponse(false, 'Not authorized!');
        }

        $db = getDB();
        $result = $db->query("SELECT * FROM requests ORDER BY created_at DESC");
        $requests = [];
        while($row = $result->fetch_assoc()) {
            $requests[] = $row;
        }
        sendResponse(true, 'Requests loaded', $requests);
        break;

    // ===== GET USER REQUESTS =====
    case 'get_user':
        if(!isset($_SESSION['user'])) {
            sendResponse(false, 'Login required!');
        }

        $userId = $_SESSION['user']['id'];
        $db = getDB();
        $stmt = $db->prepare("SELECT * FROM requests WHERE user_id = ? ORDER BY created_at DESC");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();

        $requests = [];
        while($row = $result->fetch_assoc()) {
            $requests[] = $row;
        }
        sendResponse(true, 'Requests loaded', $requests);
        break;

    // ===== UPDATE REQUEST STATUS =====
    case 'update_status':
        if(!isset($_SESSION['staff'])) {
            sendResponse(false, 'Not authorized!');
        }

        $id = intval($_POST['id'] ?? 0);
        $status = $_POST['status'] ?? '';
        $reply = trim($_POST['reply'] ?? '');
        $repliedBy = $_SESSION['staff']['name'];

        $db = getDB();
        $stmt = $db->prepare("UPDATE requests SET status=?, reply=?, replied_by=? WHERE id=?");
        $stmt->bind_param("sssi", $status, $reply, $repliedBy, $id);

        if($stmt->execute()) {
            // Get request info
            $reqResult = $db->query("SELECT * FROM requests WHERE id = $id");
            $req = $reqResult->fetch_assoc();

            // Send notification to user
            $msg = $status === 'done'
                ? "✅ Your request for '{$req['app_name']}' has been uploaded!"
                : "❌ Your request for '{$req['app_name']}' is not available.";

            $icon = $status === 'done' ? 'check-circle' : 'times-circle';

            $notifStmt = $db->prepare("INSERT INTO notifications (user_id, message, icon) VALUES (?, ?, ?)");
            $notifStmt->bind_param("iss", $req['user_id'], $msg, $icon);
            $notifStmt->execute();

            sendResponse(true, 'Status updated!');
        } else {
            sendResponse(false, 'Failed!');
        }
        break;

    default:
        sendResponse(false, 'Invalid action!');
        break;
}
?>