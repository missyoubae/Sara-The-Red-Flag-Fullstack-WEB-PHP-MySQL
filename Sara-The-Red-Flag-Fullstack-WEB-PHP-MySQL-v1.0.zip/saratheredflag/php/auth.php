<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config.php';

$action = '';
if(isset($_POST['action'])) {
    $action = $_POST['action'];
} elseif(isset($_GET['action'])) {
    $action = $_GET['action'];
}

if($action === 'register') {

    $username = isset($_POST['username']) ? trim($_POST['username']) : '';
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    $photo = isset($_POST['photo']) ? trim($_POST['photo']) : '';

    if(empty($username)) {
        sendResponse(false, 'Username is required!');
    }

    if(empty($email)) {
        sendResponse(false, 'Email is required!');
    }

    if(empty($password)) {
        sendResponse(false, 'Password is required!');
    }

    if(strlen($username) < 3) {
        sendResponse(false, 'Username must be at least 3 characters!');
    }

    if(strlen($password) < 6) {
        sendResponse(false, 'Password must be at least 6 characters!');
    }

    $db = getDB();

    $checkUser = $db->prepare("SELECT id FROM users WHERE username = ?");
    $checkUser->bind_param("s", $username);
    $checkUser->execute();
    $checkUser->store_result();

    if($checkUser->num_rows > 0) {
        sendResponse(false, 'Username already taken!');
    }

    $checkEmail = $db->prepare("SELECT id FROM users WHERE email = ?");
    $checkEmail->bind_param("s", $email);
    $checkEmail->execute();
    $checkEmail->store_result();

    if($checkEmail->num_rows > 0) {
        sendResponse(false, 'Email already registered!');
    }

    $hashedPass = password_hash($password, PASSWORD_DEFAULT);

    $stmt = $db->prepare("INSERT INTO users (username, email, password, photo, role, status) VALUES (?, ?, ?, ?, 'user', 'active')");
    $stmt->bind_param("ssss", $username, $email, $hashedPass, $photo);

    if($stmt->execute()) {
        $userId = $db->insert_id;

        $joinDate = date('Y-m-d H:i:s');
        $joinDateFormatted = date('d M Y');

        $user = array(
            'id' => $userId,
            'username' => $username,
            'email' => $email,
            'photo' => $photo,
            'role' => 'user',
            'status' => 'active',
            'join_date' => $joinDate,
            'joinDate' => $joinDateFormatted
        );

        $_SESSION['user'] = $user;
        sendResponse(true, 'Account created successfully!', $user);

    } else {
        sendResponse(false, 'Failed to create account! Error: ' . $db->error);
    }

} elseif($action === 'login') {

    $input = isset($_POST['input']) ? trim($_POST['input']) : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';

    if(empty($input) || empty($password)) {
        sendResponse(false, 'All fields required!');
    }

    $db = getDB();

    $stmt = $db->prepare("SELECT * FROM users WHERE username = ? OR email = ?");
    $stmt->bind_param("ss", $input, $input);
    $stmt->execute();
    $result = $stmt->get_result();

    if($result->num_rows === 0) {
        sendResponse(false, 'User not found!');
    }

    $user = $result->fetch_assoc();

    if($user['status'] === 'banned') {
        sendResponse(false, 'Your account is banned! Contact admin.');
    }

    if(!password_verify($password, $user['password'])) {
        sendResponse(false, 'Wrong password!');
    }

    $db->query("UPDATE users SET last_login = NOW() WHERE id = " . $user['id']);

    $joinDate = $user['join_date'];
    $joinDateFormatted = date('d M Y', strtotime($joinDate));

    $userData = array(
        'id' => $user['id'],
        'username' => $user['username'],
        'email' => $user['email'],
        'photo' => $user['photo'],
        'role' => $user['role'],
        'status' => $user['status'],
        'join_date' => $joinDate,
        'joinDate' => $joinDateFormatted
    );

    $_SESSION['user'] = $userData;
    sendResponse(true, 'Login successful!', $userData);

} elseif($action === 'staff_login') {

    $username = isset($_POST['username']) ? trim($_POST['username']) : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';

    if(empty($username) || empty($password)) {
        sendResponse(false, 'All fields required!');
    }

    $db = getDB();

    $stmt = $db->prepare("SELECT * FROM staff WHERE username = ? AND status = 'active'");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if($result->num_rows === 0) {
        sendResponse(false, 'Staff account not found!');
    }

    $staff = $result->fetch_assoc();

    if($staff['password'] !== $password) {
        sendResponse(false, 'Wrong password!');
    }

    $isAdmin = $staff['role'] === 'admin';

    $permissions = array(
        'addApps' => true,
        'editApps' => true,
        'deleteApps' => true,
        'viewRequests' => true,
        'replyRequests' => true,
        'manageStaff' => $isAdmin,
        'settings' => $isAdmin,
        'changePassword' => $isAdmin,
        'dangerZone' => $isAdmin,
        'viewWebsite' => true,
        'manageLinks' => true,
        'manageComments' => true,
        'banUsers' => true
    );

    $staffData = array(
        'id' => $staff['id'],
        'name' => $staff['name'],
        'username' => $staff['username'],
        'role' => $staff['role'],
        'roleName' => $isAdmin ? 'Admin' : 'Moderator',
        'icon' => $isAdmin ? '👑' : '🛡️',
        'permissions' => $permissions
    );

    $_SESSION['staff'] = $staffData;
    sendResponse(true, 'Login successful!', $staffData);

} elseif($action === 'logout') {

    session_destroy();
    sendResponse(true, 'Logged out successfully!');

} elseif($action === 'check') {

    if(isset($_SESSION['user'])) {
        sendResponse(true, 'User logged in', array(
            'type' => 'user',
            'data' => $_SESSION['user']
        ));
    } elseif(isset($_SESSION['staff'])) {
        sendResponse(true, 'Staff logged in', array(
            'type' => 'staff',
            'data' => $_SESSION['staff']
        ));
    } else {
        sendResponse(false, 'Not logged in');
    }

} else {
    sendResponse(false, 'Invalid action!');
}
?>