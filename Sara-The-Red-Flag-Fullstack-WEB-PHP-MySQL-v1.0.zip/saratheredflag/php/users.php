<?php
require_once 'config.php';

$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch($action) {

    // ===== GET PROFILE =====
    case 'get_profile':
        if(!isset($_SESSION['user'])) {
            sendResponse(false, 'Login required!');
        }

        $userId = $_SESSION['user']['id'];
        $db = getDB();

        $stmt = $db->prepare("SELECT id, username, email, photo, role, join_date, last_login FROM users WHERE id = ?");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();

        // Get counts
        $favCount = $db->query("SELECT COUNT(*) as c FROM favorites WHERE user_id = $userId")->fetch_assoc()['c'];
        $dlCount = $db->query("SELECT COUNT(*) as c FROM downloads WHERE user_id = $userId")->fetch_assoc()['c'];
        $reqCount = $db->query("SELECT COUNT(*) as c FROM requests WHERE user_id = $userId")->fetch_assoc()['c'];
        $notifCount = $db->query("SELECT COUNT(*) as c FROM notifications WHERE user_id = $userId AND is_read = 0")->fetch_assoc()['c'];

        $user['favorites_count'] = $favCount;
        $user['downloads_count'] = $dlCount;
        $user['requests_count'] = $reqCount;
        $user['unread_notifications'] = $notifCount;

        sendResponse(true, 'Profile loaded', $user);
        break;

    // ===== UPDATE PROFILE =====
    case 'update_profile':
        if(!isset($_SESSION['user'])) {
            sendResponse(false, 'Login required!');
        }

        $userId = $_SESSION['user']['id'];
        $username = trim($_POST['username'] ?? '');
        $photo = trim($_POST['photo'] ?? '');

        if(strlen($username) < 3) {
            sendResponse(false, 'Username too short!');
        }

        $db = getDB();

        // Check username taken
        $check = $db->prepare("SELECT id FROM users WHERE username = ? AND id != ?");
        $check->bind_param("si", $username, $userId);
        $check->execute();
        $check->store_result();

        if($check->num_rows > 0) {
            sendResponse(false, 'Username already taken!');
        }

        $stmt = $db->prepare("UPDATE users SET username = ?, photo = ? WHERE id = ?");
        $stmt->bind_param("ssi", $username, $photo, $userId);

        if($stmt->execute()) {
            $_SESSION['user']['username'] = $username;
            $_SESSION['user']['photo'] = $photo;
            sendResponse(true, 'Profile updated!');
        } else {
            sendResponse(false, 'Failed!');
        }
        break;

    // ===== CHANGE PASSWORD =====
    case 'change_password':
        if(!isset($_SESSION['user'])) {
            sendResponse(false, 'Login required!');
        }

        $userId = $_SESSION['user']['id'];
        $oldPass = $_POST['old_password'] ?? '';
        $newPass = $_POST['new_password'] ?? '';

        $db = getDB();
        $stmt = $db->prepare("SELECT password FROM users WHERE id = ?");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();

        if(!password_verify($oldPass, $user['password'])) {
            sendResponse(false, 'Current password wrong!');
        }

        if(strlen($newPass) < 6) {
            sendResponse(false, 'New password too short!');
        }

        $hashedPass = password_hash($newPass, PASSWORD_DEFAULT);
        $updateStmt = $db->prepare("UPDATE users SET password = ? WHERE id = ?");
        $updateStmt->bind_param("si", $hashedPass, $userId);

        if($updateStmt->execute()) {
            sendResponse(true, 'Password updated!');
        } else {
            sendResponse(false, 'Failed!');
        }
        break;

    // ===== GET FAVORITES =====
    case 'get_favorites':
        if(!isset($_SESSION['user'])) {
            sendResponse(false, 'Login required!');
        }

        $userId = $_SESSION['user']['id'];
        $db = getDB();

        $result = $db->query("SELECT a.* FROM apps a INNER JOIN favorites f ON a.id = f.app_id WHERE f.user_id = $userId ORDER BY f.created_at DESC");

        $favs = [];
        while($row = $result->fetch_assoc()) {
            $favs[] = $row;
        }
        sendResponse(true, 'Favorites loaded', $favs);
        break;

    // ===== GET DOWNLOADS =====
    case 'get_downloads':
        if(!isset($_SESSION['user'])) {
            sendResponse(false, 'Login required!');
        }

        $userId = $_SESSION['user']['id'];
        $db = getDB();

        $result = $db->query("SELECT * FROM downloads WHERE user_id = $userId ORDER BY downloaded_at DESC LIMIT 50");

        $downloads = [];
        while($row = $result->fetch_assoc()) {
            $downloads[] = $row;
        }
        sendResponse(true, 'Downloads loaded', $downloads);
        break;

    // ===== GET NOTIFICATIONS =====
    case 'get_notifications':
        if(!isset($_SESSION['user'])) {
            sendResponse(false, 'Login required!');
        }

        $userId = $_SESSION['user']['id'];
        $db = getDB();

        $result = $db->query("SELECT * FROM notifications WHERE user_id = $userId ORDER BY created_at DESC");

        $notifs = [];
        while($row = $result->fetch_assoc()) {
            $notifs[] = $row;
        }

        // Mark all as read
        $db->query("UPDATE notifications SET is_read = 1 WHERE user_id = $userId");

        sendResponse(true, 'Notifications loaded', $notifs);
        break;

    // ===== GET ALL USERS STAFF =====
    case 'get_all_users':
        if(!isset($_SESSION['staff'])) {
            sendResponse(false, 'Not authorized!');
        }

        $db = getDB();
        $result = $db->query("SELECT id, username, email, photo, role, status, join_date, last_login FROM users ORDER BY join_date DESC");

        $users = [];
        while($row = $result->fetch_assoc()) {
            $users[] = $row;
        }
        sendResponse(true, 'Users loaded', $users);
        break;

    // ===== BAN USER =====
    case 'ban_user':
        if(!isset($_SESSION['staff'])) {
            sendResponse(false, 'Not authorized!');
        }

        $userId = intval($_POST['user_id'] ?? 0);
        $db = getDB();
        $db->query("UPDATE users SET status = 'banned' WHERE id = $userId");
        sendResponse(true, 'User banned!');
        break;

    // ===== UNBAN USER =====
    case 'unban_user':
        if(!isset($_SESSION['staff'])) {
            sendResponse(false, 'Not authorized!');
        }

        $userId = intval($_POST['user_id'] ?? 0);
        $db = getDB();
        $db->query("UPDATE users SET status = 'active' WHERE id = $userId");
        sendResponse(true, 'User unbanned!');
        break;

    default:
        sendResponse(false, 'Invalid action!');
        break;
}
?>