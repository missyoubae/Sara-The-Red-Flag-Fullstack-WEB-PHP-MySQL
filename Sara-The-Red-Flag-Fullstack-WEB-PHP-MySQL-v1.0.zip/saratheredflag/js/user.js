// ===== CHECK LOGIN =====
window.addEventListener('load', function() {
    var user = getCurrentUser();
    if(!user) {
        window.location.href = 'user-login.html';
        return;
    }
    loadProfileFromDB();
});

// ===== FORMAT DATE =====
function formatDate(dateStr) {
    if(!dateStr || dateStr === 'undefined' || dateStr === null) {
        return 'Recently joined';
    }
    try {
        var date = new Date(dateStr);
        if(isNaN(date.getTime())) {
            return 'Recently joined';
        }
        var months = ['Jan','Feb','Mar','Apr','May','Jun',
                      'Jul','Aug','Sep','Oct','Nov','Dec'];
        return date.getDate() + ' ' + months[date.getMonth()] + ' ' + date.getFullYear();
    } catch(e) {
        return 'Recently joined';
    }
}

// ===== LOAD PROFILE FROM DB =====
function loadProfileFromDB() {
    fetch('php/users.php?action=get_profile')
    .then(function(res) { return res.json(); })
    .then(function(data) {
        if(data.success) {
            loadProfile(data.data);
            loadFavorites();
            loadHistory();
            loadRequests();
            loadNotifications();
        } else {
            var user = getCurrentUser();
            loadProfile(user);
        }
    })
    .catch(function(err) {
        var user = getCurrentUser();
        loadProfile(user);
    });
}

// ===== LOAD PROFILE =====
function loadProfile(user) {
    // Navbar
    var navUser = document.getElementById('navUsername');
    if(navUser) navUser.textContent = '👤 ' + user.username;

    // Name
    var profileName = document.getElementById('profileName');
    if(profileName) profileName.textContent = user.username;

    // Email
    var profileEmail = document.getElementById('profileEmail');
    if(profileEmail) profileEmail.textContent = user.email;

    // Join date
    var profileJoin = document.getElementById('profileJoin');
    if(profileJoin) {
        var dateStr = user.join_date || user.joinDate || user.created_at || '';
        profileJoin.textContent = '📅 Joined: ' + formatDate(dateStr);
    }

    // Role badge
    var badge = document.getElementById('profileRole');
    if(badge) {
        var roles = {
            'user': '👤 Member',
            'moderator': '🛡️ Moderator',
            'admin': '👑 Admin'
        };
        badge.textContent = roles[user.role] || '👤 Member';
    }

    // Avatar
    var avatar = document.getElementById('profileAvatar');
    if(avatar) {
        if(user.photo && user.photo !== '') {
            avatar.innerHTML = '<img src="' + user.photo + '" style="width:100%;height:100%;object-fit:cover;border-radius:50%;" onerror="this.parentElement.innerHTML=\'<i class=\\\'fas fa-user\\\'></i>\'" alt="' + user.username + '">';
        } else {
            avatar.innerHTML = '<i class="fas fa-user"></i>';
        }
    }

    // Settings inputs
    var updateUsername = document.getElementById('updateUsername');
    if(updateUsername) updateUsername.value = user.username;

    var updatePhoto = document.getElementById('updatePhoto');
    if(updatePhoto) updatePhoto.value = user.photo || '';
}

// ===== SHOW TAB =====
function showTab(name) {
    document.querySelectorAll('.tab-content').forEach(function(t) {
        t.classList.remove('active');
    });
    document.querySelectorAll('.tab-btn').forEach(function(b) {
        b.classList.remove('active');
    });

    var panel = document.getElementById('tab-' + name);
    if(panel) panel.classList.add('active');

    document.querySelectorAll('.tab-btn').forEach(function(btn) {
        if(btn.getAttribute('onclick') && btn.getAttribute('onclick').includes(name)) {
            btn.classList.add('active');
        }
    });
}

// ===== LOAD FAVORITES =====
function loadFavorites() {
    fetch('php/users.php?action=get_favorites')
    .then(function(res) { return res.json(); })
    .then(function(data) {
        var container = document.getElementById('favoritesContent');
        if(!container) return;

        if(!data.success || data.data.length === 0) {
            container.innerHTML = '<div class="empty-tab"><i class="fas fa-heart"></i><p>No favorites yet!</p><br><a href="apps.html" class="profile-btn red" style="display:inline-flex;text-decoration:none;margin:0 auto;"><i class="fas fa-download"></i> Browse Apps</a></div>';
            return;
        }

        var icons = { gaming:'gamepad', mod:'puzzle-piece', tool:'wrench' };
        var html = '<div class="favorites-grid">';
        data.data.forEach(function(fav) {
            html += '<div class="fav-card">';
            html += '<button class="fav-remove" onclick="removeFavorite(' + fav.id + ')"><i class="fas fa-times"></i></button>';
            html += '<div class="fav-icon"><i class="fas fa-' + (icons[fav.category] || 'gamepad') + '"></i></div>';
            html += '<h4>' + fav.name + '</h4>';
            html += '<p>' + fav.category + '</p>';
            html += '<a href="' + fav.mega_link + '" target="_blank" style="color:var(--red2);font-size:0.8rem;text-decoration:none;margin-top:8px;display:inline-flex;align-items:center;gap:5px;"><i class="fas fa-download"></i> Download</a>';
            html += '</div>';
        });
        html += '</div>';
        container.innerHTML = html;
    })
    .catch(function(err) { console.log('Favorites error:', err); });
}

// ===== REMOVE FAVORITE =====
function removeFavorite(appId) {
    var formData = new FormData();
    formData.append('action', 'toggle_favorite');
    formData.append('app_id', appId);

    fetch('php/apps.php', { method:'POST', body:formData })
    .then(function(res) { return res.json(); })
    .then(function(data) {
        if(data.success) {
            showToast('Removed from favorites!', 'success');
            loadFavorites();
        }
    });
}

// ===== LOAD HISTORY =====
function loadHistory() {
    fetch('php/users.php?action=get_downloads')
    .then(function(res) { return res.json(); })
    .then(function(data) {
        var container = document.getElementById('historyContent');
        if(!container) return;

        if(!data.success || data.data.length === 0) {
            container.innerHTML = '<div class="empty-tab"><i class="fas fa-history"></i><p>No download history yet!</p></div>';
            return;
        }

        var html = '<div class="history-list">';
        data.data.forEach(function(h) {
            html += '<div class="history-item">';
            html += '<div class="history-icon"><i class="fas fa-download"></i></div>';
            html += '<div class="history-info"><h4>' + h.app_name + '</h4><p>' + formatDate(h.downloaded_at) + '</p></div>';
            html += '<span class="history-date">' + formatDate(h.downloaded_at) + '</span>';
            html += '</div>';
        });
        html += '</div>';
        container.innerHTML = html;
    })
    .catch(function(err) { console.log('History error:', err); });
}

// ===== LOAD REQUESTS =====
function loadRequests() {
    fetch('php/requests.php?action=get_user')
    .then(function(res) { return res.json(); })
    .then(function(data) {
        var container = document.getElementById('myRequestsList');
        if(!container) return;

        if(!data.success || data.data.length === 0) {
            container.innerHTML = '<div class="empty-tab"><i class="fas fa-inbox"></i><p>No requests yet!</p></div>';
            return;
        }

        var html = '';
        data.data.forEach(function(r) {
            html += '<div class="req-item">';
            html += '<div style="flex:1">';
            html += '<h4 style="color:var(--white);margin-bottom:4px;">' + r.app_name + '</h4>';
            html += '<p style="color:var(--text-light);font-size:0.8rem;">' + r.category + ' • ' + formatDate(r.created_at) + '</p>';
            if(r.description) html += '<p style="color:var(--text-light);font-size:0.78rem;margin-top:3px;">' + r.description + '</p>';
            if(r.reply) html += '<p style="color:var(--red2);font-size:0.8rem;margin-top:5px;">💬 Reply: ' + r.reply + '</p>';
            html += '</div>';
            html += '<span class="req-status ' + r.status + '">' + r.status + '</span>';
            html += '</div>';
        });
        container.innerHTML = html;
    })
    .catch(function(err) { console.log('Requests error:', err); });
}

// ===== REQUEST FORM =====
document.addEventListener('DOMContentLoaded', function() {
    var requestForm = document.getElementById('requestForm');
    if(requestForm) {
        requestForm.addEventListener('submit', function(e) {
            e.preventDefault();

            var appName = document.getElementById('reqAppName').value.trim();
            var category = document.getElementById('reqCategory').value;
            var desc = document.getElementById('reqDesc').value.trim();

            if(!appName) {
                showToast('Please enter app name!', 'error');
                return;
            }

            var formData = new FormData();
            formData.append('action', 'send');
            formData.append('app_name', appName);
            formData.append('category', category);
            formData.append('description', desc);

            fetch('php/requests.php', { method:'POST', body:formData })
            .then(function(res) { return res.json(); })
            .then(function(data) {
                if(data.success) {
                    showToast('✅ Request sent to Sara!', 'success');
                    requestForm.reset();
                    loadRequests();
                } else {
                    showToast(data.message, 'error');
                }
            })
            .catch(function(err) {
                showToast('Connection error!', 'error');
            });
        });
    }
});

// ===== LOAD NOTIFICATIONS =====
function loadNotifications() {
    fetch('php/users.php?action=get_notifications')
    .then(function(res) { return res.json(); })
    .then(function(data) {
        var container = document.getElementById('notifList');
        var badge = document.getElementById('notifBadge');
        if(!container) return;

        if(!data.success || data.data.length === 0) {
            container.innerHTML = '<div class="empty-tab"><i class="fas fa-bell"></i><p>No notifications yet!</p></div>';
            return;
        }

        var unread = 0;
        var html = '';
        data.data.forEach(function(n) {
            if(!n.is_read) unread++;
            html += '<div class="notif-item ' + (n.is_read ? '' : 'unread') + '">';
            html += '<i class="fas fa-' + (n.icon || 'bell') + ' notif-icon"></i>';
            html += '<div class="notif-info"><p>' + n.message + '</p><span>' + formatDate(n.created_at) + '</span></div>';
            html += '</div>';
        });

        if(badge && unread > 0) {
            badge.style.display = 'flex';
            badge.textContent = unread;
        }

        container.innerHTML = html;
    })
    .catch(function(err) { console.log('Notifications error:', err); });
}

// ===== UPDATE PROFILE =====
function updateProfile() {
    var username = document.getElementById('updateUsername').value.trim();
    var photo = document.getElementById('updatePhoto').value.trim();

    if(!username || username.length < 3) {
        showToast('Username too short!', 'error');
        return;
    }

    var formData = new FormData();
    formData.append('action', 'update_profile');
    formData.append('username', username);
    formData.append('photo', photo);

    fetch('php/users.php', { method:'POST', body:formData })
    .then(function(res) { return res.json(); })
    .then(function(data) {
        if(data.success) {
            var user = getCurrentUser();
            user.username = username;
            user.photo = photo;
            sessionStorage.setItem('sara_current_user', JSON.stringify(user));
            loadProfile(user);
            showToast('✅ Profile updated!', 'success');
        } else {
            showToast(data.message, 'error');
        }
    });
}

// ===== CHANGE PASSWORD =====
function changeUserPassword() {
    var oldPass = document.getElementById('oldPass').value;
    var newPass = document.getElementById('newPassUser').value;
    var confirmPass = document.getElementById('confirmPassUser').value;

    if(!oldPass || !newPass || !confirmPass) {
        showToast('Fill all fields!', 'error');
        return;
    }

    if(newPass.length < 6) {
        showToast('Password too short!', 'error');
        return;
    }

    if(newPass !== confirmPass) {
        showToast('Passwords do not match!', 'error');
        return;
    }

    var formData = new FormData();
    formData.append('action', 'change_password');
    formData.append('old_password', oldPass);
    formData.append('new_password', newPass);

    fetch('php/users.php', { method:'POST', body:formData })
    .then(function(res) { return res.json(); })
    .then(function(data) {
        if(data.success) {
            document.getElementById('oldPass').value = '';
            document.getElementById('newPassUser').value = '';
            document.getElementById('confirmPassUser').value = '';
            showToast('✅ Password changed!', 'success');
        } else {
            showToast(data.message, 'error');
        }
    });
}

// ===== TOAST =====
function showToast(message, type) {
    type = type || 'success';
    var toast = document.getElementById('toast');
    var toastText = document.getElementById('toastText');
    if(!toast || !toastText) return;
    toast.className = 'toast ' + type + ' show';
    toastText.textContent = message;
    setTimeout(function() {
        toast.classList.remove('show');
    }, 3000);
}

// ===== LOGOUT =====
function userLogout() {
    if(confirm('Are you sure you want to logout?')) {
        fetch('php/auth.php', {
            method: 'POST',
            body: new URLSearchParams({ action: 'logout' })
        })
        .finally(function() {
            sessionStorage.removeItem('sara_current_user');
            window.location.href = 'index.html';
        });
    }
}