// ===== GET CURRENT USER =====
function getCurrentUser() {
    const data = sessionStorage.getItem('sara_current_user');
    return data ? JSON.parse(data) : null;
}

// ===== SET CURRENT USER =====
function setCurrentUser(user) {
    sessionStorage.setItem('sara_current_user', JSON.stringify(user));
}

// ===== UPDATE CURRENT USER =====
function updateCurrentUser(updatedUser) {
    const formData = new FormData();
    formData.append('action', 'update_profile');
    formData.append('username', updatedUser.username);
    formData.append('photo', updatedUser.photo || '');

    fetch('php/users.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if(data.success) {
            sessionStorage.setItem(
                'sara_current_user',
                JSON.stringify(updatedUser)
            );
        }
    });
}

// ===== USER LOGOUT =====
function userLogout() {
    if(confirm('Are you sure you want to logout?')) {
        fetch('php/auth.php', {
            method: 'POST',
            body: new URLSearchParams({ action: 'logout' })
        })
        .finally(() => {
            sessionStorage.removeItem('sara_current_user');
            window.location.href = 'index.html';
        });
    }
}

// ===== GET USERS =====
function getUsers() {
    return JSON.parse(localStorage.getItem('sara_users') || '[]');
}

// ===== SAVE USERS =====
function saveUsers(users) {
    localStorage.setItem('sara_users', JSON.stringify(users));
}