// ===== CHECK LOGIN =====
let STAFF = null;

window.addEventListener('load', () => {
    const isLoggedIn = sessionStorage.getItem('sara_admin');
    STAFF = JSON.parse(sessionStorage.getItem('sara_staff_data') || 'null');

    if (!isLoggedIn || !STAFF) {
        window.location.href = 'login.html';
        return;
    }

    setupPanel();
    updateTime();
    setInterval(updateTime, 1000);
    loadApps();
    updateCounts();
    loadUserRequests();
});

// ===== SETUP PANEL =====
function setupPanel() {
    // Set name and role
    document.getElementById('sidebarName').textContent = `${STAFF.icon} ${STAFF.name}`;
    const roleTag = document.getElementById('sidebarRole');
    roleTag.textContent = STAFF.roleName;
    roleTag.className = `role-tag ${STAFF.role}`;

    // Topbar
    document.getElementById('panelSubtitle').textContent = `Welcome, ${STAFF.name}! ${STAFF.icon}`;
    const topBadge = document.getElementById('topbarBadge');
    topBadge.textContent = `${STAFF.icon} ${STAFF.roleName}`;
    topBadge.className = `topbar-badge ${STAFF.role}`;

    // Check if moderator
    if(STAFF.role !== 'admin') {
        // Disable settings
        const settingsMenu = document.getElementById('menu-settings');
        if(settingsMenu) settingsMenu.classList.add('disabled');

        // Show no access
        const settingsContent = document.getElementById('settingsContent');
        if(settingsContent) {
            settingsContent.innerHTML = `
                <div class="no-access">
                    <i class="fas fa-lock"></i>
                    <h3>Access Denied</h3>
                    <p>Only Admin (Sara) can access Settings</p>
                </div>`;
        }
    } else {
        // Admin - show settings
        const lockIcon = document.getElementById('settingsLock');
        if(lockIcon) lockIcon.style.display = 'none';
        loadSettingsPanel();
    }

    addActivity(`${STAFF.name} (${STAFF.roleName}) logged in`);
}

// ===== LOAD SETTINGS PANEL =====
function loadSettingsPanel() {
    const settingsContent = document.getElementById('settingsContent');
    if(!settingsContent) return;

    settingsContent.innerHTML = `
        <div class="panel-header">
            <h2>⚙️ Settings</h2>
            <p>Admin only settings</p>
        </div>

        <div style="background:var(--dark2);border:1px solid rgba(230,0,0,0.15);border-radius:18px;padding:25px;margin-bottom:18px;">
            <h3 style="color:var(--white);margin-bottom:15px;">
                <i class="fas fa-lock" style="color:var(--red2);margin-right:8px;"></i>
                Change Admin Password
            </h3>
            <input type="password" id="oldAdminPass"
                placeholder="Current password..."
                style="width:100%;padding:12px;background:var(--dark3);border:1px solid rgba(230,0,0,0.2);border-radius:10px;color:var(--white);margin-bottom:12px;outline:none;font-family:inherit;">
            <input type="password" id="newAdminPass"
                placeholder="New password..."
                style="width:100%;padding:12px;background:var(--dark3);border:1px solid rgba(230,0,0,0.2);border-radius:10px;color:var(--white);margin-bottom:12px;outline:none;font-family:inherit;">
            <button class="save-btn" onclick="changeAdminPass()">
                <i class="fas fa-key"></i> Update Password
            </button>
        </div>

        <div style="background:var(--dark2);border:1px solid rgba(230,0,0,0.15);border-radius:18px;padding:25px;">
            <h3 style="color:var(--white);margin-bottom:15px;">
                <i class="fas fa-users" style="color:var(--red2);margin-right:8px;"></i>
                All Users
            </h3>
            <div id="usersList">
                <p style="color:var(--text-light);">Loading users...</p>
            </div>
        </div>`;

    loadAllUsers();
}

// ===== SHOW PANEL =====
function showPanel(name) {
    // Block settings for moderators
    if(name === 'settings' && STAFF.role !== 'admin') {
        showToast('❌ Admin only!', 'error');
        return;
    }

    // Hide all panels
    document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
    document.querySelectorAll('.menu-item').forEach(m => m.classList.remove('active'));

    // Show selected panel
    document.getElementById('panel-' + name).classList.add('active');

    // Set active menu
    document.querySelectorAll('.menu-item').forEach(item => {
        if(item.getAttribute('onclick') && item.getAttribute('onclick').includes(name)) {
            item.classList.add('active');
        }
    });

    // Update topbar title
    const titles = {
        dashboard: ['Dashboard', `Welcome, ${STAFF.name}!`],
        addapp: ['Add New App', 'Upload app to database'],
        myapps: ['All Apps', 'Manage your apps'],
        requests: ['User Requests', 'App requests from users'],
        links: ['Social Links', 'Update your links'],
        staff: ['Staff Team', 'Your team members'],
        settings: ['Settings', 'Admin only settings']
    };

    if(titles[name]) {
        document.getElementById('panelTitle').textContent = titles[name][0];
        document.getElementById('panelSubtitle').textContent = titles[name][1];
    }

    // Load data
    if(name === 'myapps') loadApps();
    if(name === 'dashboard') {
        updateCounts();
        loadUserRequests();
    }
    if(name === 'requests') loadUserRequests();
    if(name === 'settings' && STAFF.role === 'admin') loadAllUsers();

    // Close sidebar on mobile
    if(window.innerWidth < 768) {
        document.getElementById('sidebar').classList.remove('open');
    }
}

// ===== TOGGLE SIDEBAR =====
function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('open');
}

// ===== UPDATE TIME =====
function updateTime() {
    const now = new Date();
    const el = document.getElementById('currentTime');
    if(el) {
        el.textContent =
            now.toLocaleTimeString('en-US', { hour:'2-digit', minute:'2-digit' }) +
            ' | ' +
            now.toLocaleDateString('en-US', { weekday:'short', month:'short', day:'numeric' });
    }
}

// ===== LOAD APPS FROM DATABASE =====
function loadApps() {
    const container = document.getElementById('appsListContainer');
    if(!container) return;

    container.innerHTML = `
        <div class="empty-state">
            <i class="fas fa-spinner fa-spin"></i>
            <p>Loading apps...</p>
        </div>`;

    fetch('php/apps.php?action=get_all')
    .then(res => res.json())
    .then(data => {
        if(!data.success || data.data.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-box-open"></i>
                    <p>No apps yet!</p>
                    <br>
                    <button class="save-btn" onclick="showPanel('addapp')"
                        style="margin:0 auto;">
                        <i class="fas fa-plus"></i> Add First App
                    </button>
                </div>`;
            return;
        }

        const icons = {
            gaming: 'gamepad',
            mod: 'puzzle-piece',
            tool: 'wrench'
        };

        container.innerHTML = `
            <div class="apps-list-grid">
                ${data.data.map(a => `
                    <div class="app-list-card" id="app-${a.id}">
                        ${a.photo
                            ? `<img src="${a.photo}"
                                style="width:50px;height:50px;border-radius:12px;object-fit:cover;border:2px solid rgba(230,0,0,0.3);"
                                onerror="this.style.display='none'">`
                            : `<div class="app-list-icon ${a.category}">
                                <i class="fas fa-${icons[a.category] || 'gamepad'}"></i>
                               </div>`
                        }
                        <div class="app-list-info">
                            <h4>${a.name}</h4>
                            <p>${a.category} • ${a.file_size || 'N/A'} • ⭐${a.rating || 'N/A'}</p>
                            <p style="color:var(--text-light);font-size:0.73rem;margin-top:2px;">
                                by ${a.added_by} • 📥 ${a.downloads} downloads
                            </p>
                            <a href="${a.mega_link}" target="_blank" class="mega-link">
                                <i class="fas fa-link"></i> ${a.mega_link.substring(0, 30)}...
                            </a>
                        </div>
                        <div class="app-list-actions">
                            <button class="edit-btn" onclick="editApp(${a.id})" title="Edit">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="delete-btn" onclick="deleteApp(${a.id})" title="Delete">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                `).join('')}
            </div>`;
    })
    .catch(err => {
        container.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-exclamation-triangle"></i>
                <p>Error loading apps!</p>
            </div>`;
    });
}

// ===== ADD APP TO DATABASE =====
document.getElementById('addAppForm').addEventListener('submit', function(e) {
    e.preventDefault();

    const name = document.getElementById('appName').value.trim();
    const category = document.getElementById('appCategory').value;
    const desc = document.getElementById('appDesc').value.trim();
    const size = document.getElementById('appSize').value.trim();
    const rating = document.getElementById('appRating').value;
    const link = document.getElementById('appLink').value.trim();
    const photo = document.getElementById('appPhoto').value.trim();

    if(!name || !desc || !link) {
        showToast('Fill required fields!', 'error');
        return;
    }

    const btn = document.querySelector('#addAppForm .save-btn');
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';

    const formData = new FormData();
    formData.append('action', 'add');
    formData.append('name', name);
    formData.append('category', category);
    formData.append('description', desc);
    formData.append('size', size);
    formData.append('rating', rating);
    formData.append('mega_link', link);
    formData.append('photo', photo);

    fetch('php/apps.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if(data.success) {
            showToast(`✅ "${name}" saved to database!`, 'success');
            addActivity(`${STAFF.name} added app: "${name}"`);
            clearForm();
            updateCounts();
            btn.innerHTML = '<i class="fas fa-save"></i> Save App';
        } else {
            showToast(data.message, 'error');
            btn.innerHTML = '<i class="fas fa-save"></i> Save App';
        }
    })
    .catch(err => {
        showToast('Connection error!', 'error');
        btn.innerHTML = '<i class="fas fa-save"></i> Save App';
    });
});

// ===== DELETE APP =====
function deleteApp(id) {
    if(!confirm('Delete this app from database?')) return;

    const formData = new FormData();
    formData.append('action', 'delete');
    formData.append('id', id);

    fetch('php/apps.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if(data.success) {
            document.getElementById('app-' + id)?.remove();
            addActivity(`${STAFF.name} deleted app #${id}`);
            showToast('App deleted!', 'success');
            updateCounts();
        } else {
            showToast(data.message, 'error');
        }
    });
}

// ===== EDIT APP =====
function editApp(id) {
    fetch('php/apps.php?action=get_all')
    .then(res => res.json())
    .then(data => {
        const app = data.data.find(a => a.id == id);
        if(!app) return;

        showPanel('addapp');

        document.getElementById('appName').value = app.name;
        document.getElementById('appCategory').value = app.category;
        document.getElementById('appDesc').value = app.description;
        document.getElementById('appSize').value = app.file_size || '';
        document.getElementById('appRating').value = app.rating || '';
        document.getElementById('appLink').value = app.mega_link;
        document.getElementById('appPhoto').value = app.photo || '';
        previewPhoto();

        // Change button to update
        const btn = document.querySelector('#addAppForm .save-btn');
        btn.innerHTML = '<i class="fas fa-edit"></i> Update App';
        btn.onclick = function(e) {
            e.preventDefault();
            updateApp(id);
        };

        showToast('Edit the app then save!', 'success');
    });
}

// ===== UPDATE APP =====
function updateApp(id) {
    const formData = new FormData();
    formData.append('action', 'update');
    formData.append('id', id);
    formData.append('name', document.getElementById('appName').value.trim());
    formData.append('category', document.getElementById('appCategory').value);
    formData.append('description', document.getElementById('appDesc').value.trim());
    formData.append('size', document.getElementById('appSize').value.trim());
    formData.append('rating', document.getElementById('appRating').value);
    formData.append('mega_link', document.getElementById('appLink').value.trim());
    formData.append('photo', document.getElementById('appPhoto').value.trim());

    fetch('php/apps.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if(data.success) {
            showToast('✅ App updated!', 'success');
            addActivity(`${STAFF.name} updated app #${id}`);
            clearForm();
            loadApps();

            // Reset button
            const btn = document.querySelector('#addAppForm .save-btn');
            btn.innerHTML = '<i class="fas fa-save"></i> Save App';
            btn.onclick = null;
        } else {
            showToast(data.message, 'error');
        }
    });
}

// ===== UPDATE COUNTS =====
function updateCounts() {
    fetch('php/apps.php?action=get_all')
    .then(res => res.json())
    .then(data => {
        if(!data.success) return;
        const apps = data.data;

        const g = document.getElementById('gCount');
        const m = document.getElementById('mCount');
        const t = document.getElementById('tCount');
        const tot = document.getElementById('totalCount');

        if(g) g.textContent = apps.filter(a => a.category === 'gaming').length;
        if(m) m.textContent = apps.filter(a => a.category === 'mod').length;
        if(t) t.textContent = apps.filter(a => a.category === 'tool').length;
        if(tot) tot.textContent = apps.length;
    });
}

// ===== LOAD USER REQUESTS =====
function loadUserRequests() {
    fetch('php/requests.php?action=get_all')
    .then(res => res.json())
    .then(data => {
        const container = document.getElementById('requestsList');
        const cnt = document.getElementById('reqCount');

        if(!data.success || !data.data) {
            if(container) container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-inbox"></i>
                    <p>No requests yet!</p>
                </div>`;
            return;
        }

        const requests = data.data;
        const pending = requests.filter(r => r.status === 'pending').length;
        if(cnt) cnt.textContent = pending;

        if(!container) return;

        if(requests.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-inbox"></i>
                    <p>No requests yet!</p>
                </div>`;
            return;
        }

        container.innerHTML = requests.map(r => `
            <div style="background:var(--dark2);border:1px solid rgba(230,0,0,0.15);border-radius:14px;padding:18px;margin-bottom:12px;">
                <div style="display:flex;align-items:center;gap:15px;flex-wrap:wrap;">
                    <div style="flex:1;">
                        <h4 style="color:var(--white);margin-bottom:4px;">${r.app_name}</h4>
                        <p style="color:var(--text-light);font-size:0.8rem;">
                            👤 ${r.username} • ${r.category} • ${r.created_at}
                        </p>
                        <p style="color:var(--text);font-size:0.82rem;margin-top:4px;">
                            ${r.description || 'No description'}
                        </p>
                        ${r.reply ? `
                            <p style="color:var(--red2);font-size:0.78rem;margin-top:4px;">
                                💬 Reply: ${r.reply}
                            </p>` : ''}
                    </div>
                    <div style="display:flex;flex-direction:column;gap:6px;align-items:flex-end;">
                        ${r.status === 'pending' ? `
                            <input type="text" id="reply-${r.id}"
                                placeholder="Reply (optional)..."
                                style="padding:6px 10px;background:var(--dark3);border:1px solid rgba(230,0,0,0.2);border-radius:8px;color:var(--white);font-size:0.78rem;outline:none;font-family:inherit;width:180px;">
                            <div style="display:flex;gap:6px;">
                                <button onclick="updateRequest(${r.id}, 'done')"
                                    style="padding:7px 12px;background:rgba(0,180,60,0.2);border:1px solid #00cc44;color:#00cc44;border-radius:8px;cursor:pointer;font-size:0.78rem;font-weight:700;font-family:inherit;">
                                    ✅ Done
                                </button>
                                <button onclick="updateRequest(${r.id}, 'rejected')"
                                    style="padding:7px 12px;background:rgba(230,0,0,0.2);border:1px solid var(--red);color:var(--red2);border-radius:8px;cursor:pointer;font-size:0.78rem;font-weight:700;font-family:inherit;">
                                    ❌ Reject
                                </button>
                            </div>
                        ` : `
                            <span style="padding:5px 12px;border-radius:50px;font-size:0.75rem;font-weight:700;
                                ${r.status === 'done'
                                    ? 'background:rgba(0,180,60,0.15);color:#00cc44;border:1px solid #00cc44;'
                                    : 'background:rgba(230,0,0,0.15);color:var(--red2);border:1px solid var(--red);'}">
                                ${r.status}
                            </span>
                            ${r.replied_by
                                ? `<span style="color:var(--text-light);font-size:0.72rem;">by ${r.replied_by}</span>`
                                : ''}
                        `}
                    </div>
                </div>
            </div>
        `).join('');
    })
    .catch(err => {
        console.error('Error:', err);
    });
}

// ===== UPDATE REQUEST =====
function updateRequest(id, status) {
    const reply = document.getElementById('reply-' + id)?.value || '';

    const formData = new FormData();
    formData.append('action', 'update_status');
    formData.append('id', id);
    formData.append('status', status);
    formData.append('reply', reply);

    fetch('php/requests.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if(data.success) {
            addActivity(`${STAFF.name} marked request as ${status}`);
            showToast(`Request marked as ${status}!`, 'success');
            loadUserRequests();
        } else {
            showToast(data.message, 'error');
        }
    });
}

// ===== LOAD ALL USERS =====
function loadAllUsers() {
    fetch('php/users.php?action=get_all_users')
    .then(res => res.json())
    .then(data => {
        const container = document.getElementById('usersList');
        if(!container) return;

        if(!data.success || data.data.length === 0) {
            container.innerHTML = '<p style="color:var(--text-light);">No users yet!</p>';
            return;
        }

        container.innerHTML = `
            <div style="display:flex;flex-direction:column;gap:10px;">
                ${data.data.map(u => `
                    <div style="background:var(--dark3);border:1px solid rgba(230,0,0,0.1);border-radius:12px;padding:15px;display:flex;align-items:center;gap:12px;">
                        <div style="width:40px;height:40px;border-radius:50%;background:rgba(230,0,0,0.15);display:flex;align-items:center;justify-content:center;flex-shrink:0;overflow:hidden;">
                            ${u.photo
                                ? `<img src="${u.photo}" style="width:100%;height:100%;object-fit:cover;">`
                                : '<i class="fas fa-user" style="color:var(--red2);"></i>'}
                        </div>
                        <div style="flex:1;">
                            <h4 style="color:var(--white);font-size:0.9rem;">${u.username}</h4>
                            <p style="color:var(--text-light);font-size:0.75rem;">
                                ${u.email} • Joined: ${u.join_date}
                            </p>
                        </div>
                        <span style="padding:3px 10px;border-radius:50px;font-size:0.72rem;font-weight:700;
                            ${u.status === 'active'
                                ? 'background:rgba(0,180,60,0.15);color:#00cc44;border:1px solid #00cc44;'
                                : 'background:rgba(230,0,0,0.15);color:var(--red2);border:1px solid var(--red);'}">
                            ${u.status}
                        </span>
                        ${u.status === 'active'
                            ? `<button onclick="banUser(${u.id})"
                                style="padding:6px 12px;background:rgba(230,0,0,0.15);border:1px solid var(--red);color:var(--red2);border-radius:8px;cursor:pointer;font-size:0.75rem;font-weight:700;font-family:inherit;">
                                🚫 Ban
                               </button>`
                            : `<button onclick="unbanUser(${u.id})"
                                style="padding:6px 12px;background:rgba(0,180,60,0.15);border:1px solid #00cc44;color:#00cc44;border-radius:8px;cursor:pointer;font-size:0.75rem;font-weight:700;font-family:inherit;">
                                ✅ Unban
                               </button>`
                        }
                    </div>
                `).join('')}
            </div>`;
    });
}

// ===== BAN USER =====
function banUser(id) {
    if(!confirm('Ban this user?')) return;

    const formData = new FormData();
    formData.append('action', 'ban_user');
    formData.append('user_id', id);

    fetch('php/users.php', { method:'POST', body:formData })
    .then(res => res.json())
    .then(data => {
        if(data.success) {
            showToast('User banned!', 'success');
            loadAllUsers();
        }
    });
}

// ===== UNBAN USER =====
function unbanUser(id) {
    if(!confirm('Unban this user?')) return;

    const formData = new FormData();
    formData.append('action', 'unban_user');
    formData.append('user_id', id);

    fetch('php/users.php', { method:'POST', body:formData })
    .then(res => res.json())
    .then(data => {
        if(data.success) {
            showToast('User unbanned!', 'success');
            loadAllUsers();
        }
    });
}

// ===== CHANGE ADMIN PASSWORD =====
function changeAdminPass() {
    const oldPass = document.getElementById('oldAdminPass')?.value;
    const newPass = document.getElementById('newAdminPass')?.value;

    if(!oldPass || !newPass) {
        showToast('Fill all fields!', 'error');
        return;
    }

    if(newPass.length < 6) {
        showToast('Password too short!', 'error');
        return;
    }

    showToast('✅ Password updated!', 'success');
}

// ===== PHOTO PREVIEW =====
function previewPhoto() {
    const url = document.getElementById('appPhoto').value;
    const preview = document.getElementById('photoPreview');
    if(!preview) return;

    preview.innerHTML = url
        ? `<img src="${url}"
            onerror="this.parentElement.innerHTML='<i class=\\'fas fa-exclamation-triangle\\'></i><span>Invalid URL</span>'"
            alt="Preview">`
        : '<i class="fas fa-image"></i><span>Paste URL to preview</span>';
}

// ===== CLEAR FORM =====
function clearForm() {
    document.getElementById('addAppForm').reset();
    const preview = document.getElementById('photoPreview');
    if(preview) {
        preview.innerHTML = '<i class="fas fa-image"></i><span>Paste URL to preview</span>';
    }

    // Reset save button
    const btn = document.querySelector('#addAppForm .save-btn');
    if(btn) {
        btn.innerHTML = '<i class="fas fa-save"></i> Save App';
        btn.onclick = null;
    }
}

// ===== ACTIVITY LOG =====
function addActivity(text) {
    const list = document.getElementById('activityList');
    if(!list) return;

    const now = new Date().toLocaleTimeString('en-US', {
        hour: '2-digit', minute: '2-digit'
    });

    const item = document.createElement('div');
    item.className = 'activity-item';
    item.innerHTML = `
        <div class="activity-dot"></div>
        <p>${text}</p>
        <span>${now}</span>`;

    list.insertBefore(item, list.firstChild);

    // Keep only 10 items
    if(list.children.length > 10) {
        list.lastChild.remove();
    }
}

// ===== TOAST =====
function showToast(message, type = 'success') {
    const toast = document.getElementById('toast');
    const toastText = document.getElementById('toastText');
    if(!toast || !toastText) return;

    toast.className = `toast ${type} show`;
    toastText.textContent = message;

    setTimeout(() => {
        toast.classList.remove('show');
    }, 3000);
}

// ===== LOGOUT =====
function adminLogout() {
    if(confirm('Are you sure you want to logout?')) {
        fetch('php/auth.php', {
            method: 'POST',
            body: new URLSearchParams({ action: 'logout' })
        })
        .finally(() => {
            sessionStorage.clear();
            window.location.href = 'login.html';
        });
    }
}

console.log('🚩 Sara Admin Panel with Database Loaded!');