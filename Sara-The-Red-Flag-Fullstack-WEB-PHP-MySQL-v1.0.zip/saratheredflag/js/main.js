// ===== NAVBAR SCROLL =====
const navbar = document.querySelector('.navbar');
window.addEventListener('scroll', () => {
    if (window.scrollY > 50) {
        navbar.style.boxShadow = '0 5px 25px rgba(230,0,0,0.2)';
    } else {
        navbar.style.boxShadow = 'none';
    }
});

// ===== HAMBURGER MENU =====
const hamburger = document.querySelector('.hamburger');
const navLinks = document.querySelector('.nav-links');

if (hamburger) {
    hamburger.addEventListener('click', () => {
        navLinks.classList.toggle('active');
        const spans = hamburger.querySelectorAll('span');
        const isOpen = navLinks.classList.contains('active');
        spans[0].style.transform = isOpen ? 'rotate(45deg) translate(5px, 6px)' : '';
        spans[1].style.opacity = isOpen ? '0' : '1';
        spans[2].style.transform = isOpen ? 'rotate(-45deg) translate(5px, -6px)' : '';
    });
}

document.querySelectorAll('.nav-links a').forEach(link => {
    link.addEventListener('click', () => {
        if (navLinks) navLinks.classList.remove('active');
    });
});

// ===== SCROLL TOP BUTTON =====
const scrollTopBtn = document.querySelector('.scroll-top');
window.addEventListener('scroll', () => {
    if (scrollTopBtn) {
        scrollTopBtn.style.display = window.scrollY > 400 ? 'flex' : 'none';
    }
});

// ===== FILTER APPS =====
function filterApps(category) {
    const cards = document.querySelectorAll('.big-app-card');
    const buttons = document.querySelectorAll('.filter-btn');

    buttons.forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');

    cards.forEach(card => {
        if (category === 'all' || card.dataset.category === category) {
            card.style.display = 'flex';
            card.style.animation = 'fadeInUp 0.4s ease';
        } else {
            card.style.display = 'none';
        }
    });
}

// ===== NEWSLETTER SUBMIT =====
function submitNewsletter(e) {
    e.preventDefault();
    const input = e.target.querySelector('input');
    const btn = e.target.querySelector('button');
    if (input.value) {
        btn.innerHTML = '✅ Subscribed!';
        btn.style.background = 'linear-gradient(135deg, #00cc44, #009933)';
        input.value = '';
        setTimeout(() => {
            btn.innerHTML = 'Notify Me';
            btn.style.background = '';
        }, 3000);
    }
}

// ===== CONTACT FORM =====
const contactForm = document.getElementById('contactForm');
if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const btn = contactForm.querySelector('button[type="submit"]');
        btn.innerHTML = '<i class="fas fa-check"></i> Message Sent!';
        btn.style.background = 'linear-gradient(135deg, #00cc44, #009933)';
        setTimeout(() => {
            btn.innerHTML = '<i class="fas fa-paper-plane"></i> Send Message';
            btn.style.background = '';
            contactForm.reset();
        }, 3000);
    });
}

// ===== SCROLL ANIMATION =====
const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.animation = 'fadeInUp 0.6s ease forwards';
            entry.target.style.opacity = '1';
        }
    });
}, { threshold: 0.1 });

document.querySelectorAll('.offer-card, .app-card, .big-app-card, .yt-cat-card, .contact-card').forEach(el => {
    el.style.opacity = '0';
    observer.observe(el);
});

// ===== PLAY BUTTON =====
const playBtn = document.querySelector('.play-btn');
if (playBtn) {
    playBtn.addEventListener('click', () => {
        window.open('https://www.youtube.com/@SaraTheRedFlagNew/videos', '_blank');
    });
}

const ytThumb = document.querySelector('.yt-thumbnail');
if (ytThumb) {
    ytThumb.addEventListener('click', () => {
        window.open('https://www.youtube.com/@SaraTheRedFlagNew/videos', '_blank');
    });
    ytThumb.style.cursor = 'pointer';
}

console.log('🚩 Sara The Red Flag Website Loaded!');